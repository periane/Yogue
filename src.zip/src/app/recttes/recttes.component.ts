import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recttes',
  templateUrl: './recttes.component.html',
  styleUrls: ['./recttes.component.css']
})
export class RecttesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
