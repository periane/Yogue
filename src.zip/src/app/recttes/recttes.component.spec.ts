import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecttesComponent } from './recttes.component';

describe('RecttesComponent', () => {
  let component: RecttesComponent;
  let fixture: ComponentFixture<RecttesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecttesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecttesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
