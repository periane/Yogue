import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conseil',
  templateUrl: './conseil.component.html',
  styleUrls: ['./conseil.component.css']
})
export class ConseilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
